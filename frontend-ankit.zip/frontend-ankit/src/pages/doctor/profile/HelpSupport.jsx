import React from "react";

const Help = () => {
  return (
    <div className="min-h-screen flex items-center justify-center text-xl font-semibold text-[#0A4D68]">
      Help & Support Page (coming soon...)
    </div>
  );
};

export default Help;
